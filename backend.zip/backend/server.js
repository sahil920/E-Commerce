const express = require("express")
const app = express()
const {errorHandler} = require("./middlewares/errorMiddleware")
const cors = require("cors")
const products = require("./data/products")
const dotenv = require("dotenv")
const connectDb = require("./config/config")
const mongoose = require("mongoose")
const colors = require("colors")
const productRoutes = require("./routes/productsRoute")
// const myfunc= require("./config/config")
// dotenv confgi
dotenv.config()
// connectting to mongo db database
connectDb()

app.use(
    cors({
        origin:"http://localhost:3000",
    })
) 



app.get('/', (req, res)=>{
    res.send("welcome to node server")
})

app.use("/api",productRoutes)
// mongoose.connect('mongodb+srv://sahilkhan:dwv3duiYnLMRH5n6@cluster0.3wbgoiy.mongodb.net/?retryWrites=true&w=majority');

// mongoose.connection.on('error', err=>{
//     console.log('connection failed');

// })

// mongoose.connection.on('connected', connected=>{
//     console.log('connected with the data base');

// });



app.use(errorHandler)
const PORT =8080;
app.listen(process.env.PORT || PORT, ()=>{
    console.log(`Server is listening in Mode on Port : ${process.env.PORT}`)
})